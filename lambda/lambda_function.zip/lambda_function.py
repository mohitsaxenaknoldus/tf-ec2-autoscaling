import os
import boto3

def lambda_handler(event, context):
    auto_scaling_group_name = os.environ['AUTO_SCALING_GROUP_NAME']

    client = boto3.client('autoscaling')
    response = client.start_instance_refresh(
        AutoScalingGroupName=auto_scaling_group_name,
        Strategy='Rolling',
        Preferences={
            'MinHealthyPercentage': 90
        }
    )
    return response
